import { Component, createElement } from "react";
import { hot } from "react-hot-loader/root";

import "./ui/TwilioVideoChat.css";
import { buildWidgetEvent, emitWidgetEvent } from "./services/eventLogger";
import { performDeviceCheck } from "./services/deviceService";
import {
  WIDGET_VERSION,
  WIDGET_FEATURES,
  TWILIO_SDK_VERSION
} from "./version";

var Video = require('twilio-video');

var chat;
var joinRoomToggle;
var previewToggle;
var activeRoom;
//Prevent double connection 
var connectionInProgress = false;

var localTracks;
var participantContainers = {};
var isAgent = chat.props.participantSide === "agent";
var isCustomer = chat.props.participantSide === "customer";

var focusLost = false;

function getConnectionState() {
  if (connectionInProgress) {
    return "Connecting";
  }

  if (activeRoom) {
    return "Connected";
  }

  if (localTracks) {
    return "Preview";
  }

  return "Disconnected";
}

function getBrowserInfo() {
  return navigator.userAgent || "";
}


function handleFocusLost() {
  if (!focusLost) {
    focusLost = true;
    log("Focus lost");

    sendWidgetEvent(
      "FOCUS_LOST",
      "WARNING",
      "Browser focus lost or page became hidden"
    );

  }
}

function handleFocusReturned() {
  if (focusLost) {
    focusLost = false;
    log("Focus returned");

    sendWidgetEvent(
      "FOCUS_RETURNED",
      "INFO",
      "Browser focus returned or page became visible"
    );

  }
}

function getIntegerProp(propName, defaultValue) {
  const prop = chat && chat.props ? chat.props[propName] : null;

  if (!prop || prop.value === undefined || prop.value === null) {
    return defaultValue;
  }

  var parsedValue = parseInt(prop.value, 10);

  return isNaN(parsedValue) ? defaultValue : parsedValue;
}

// When we are about to transition away from this page, disconnect
// from the room, if joined.
window.addEventListener('beforeunload', leaveRoom);

window.addEventListener("blur", handleFocusLost);
window.addEventListener("focus", handleFocusReturned);

document.addEventListener("visibilitychange", function() {
  if (document.hidden) {
    handleFocusLost();
  } else {
    handleFocusReturned();
  }
});

function getBooleanProp(propName, defaultValue) {
    const prop = chat && chat.props ? chat.props[propName] : null;

    if (!prop || prop.value === undefined || prop.value === null) {
        return defaultValue;
    }

    return prop.value;
}


function getParticipantSide() {
    return chat && chat.props && chat.props.participantSide
        ? chat.props.participantSide
        : "customer";
}

function isAgentParticipant() {
    return getParticipantSide() === "agent";
}

function getDefaultMediaEnabled() {
    return isAgentParticipant() ? false : true;
}

function hasActiveLocalTracks() {
  return localTracks && localTracks.some(function(track) {
    return track.mediaStreamTrack &&
      track.mediaStreamTrack.readyState === "live";
  });
}

async function joinRoom() {
  var roomName = chat.props.roomNameExpr.value;
  var identity = chat.props.nickNameExpr.value;
  var token = chat.props.accessTokenExpr.value;

  if (!roomName || !identity || !token) {
    return;
  }

  if (connectionInProgress) {
    log("Connection already in progress");
    return;
  }

  connectionInProgress = true;
  joinRoomToggle = true;

  var isAgent = isAgentParticipant();
  var defaultMediaEnabled = getDefaultMediaEnabled();
  var audioEnabled = getBooleanProp("microphoneEnabledExpr", defaultMediaEnabled);
  var videoEnabled = getBooleanProp("cameraEnabledExpr", defaultMediaEnabled);
  var videoWidth = getIntegerProp("videoWidth", 640);
  var videoHeight = getIntegerProp("videoHeight", 480);

  var connectOptions = {
    name: roomName,
    logLevel: "warn"
  };

  if (isAgent) {
    log("Agent joining without local audio/video tracks");

    sendWidgetEvent(
      "DEVICE_CHECK_SKIPPED",
      "INFO",
      "Device check skipped for agent participant without local media",
      {
        participantSide: getParticipantSide(),
        audioEnabled: false,
        videoEnabled: false
      }
    );

    connectOptions.tracks = [];

    Video.connect(token, connectOptions).then(
      function(room) {
        roomJoined(room, identity);
      },
      function(error) {
        joinRoomToggle = false;
        connectionInProgress = false;
        handleError("Could not connect to Twilio", error);
      }
    );

    return;
  }

  sendWidgetEvent(
    "DEVICE_CHECK_STARTED",
    "INFO",
    "Device check started",
    {
      participantSide: getParticipantSide(),
      audioEnabled: audioEnabled,
      videoEnabled: videoEnabled,
      videoWidth: videoWidth,
      videoHeight: videoHeight
    }
  );

  const deviceCheckResult = await performDeviceCheck({
    requireCamera: videoEnabled,
    requireMicrophone: audioEnabled
  });

  if (!deviceCheckResult.success) {
    sendWidgetEvent(
      "DEVICE_CHECK_FAILED",
      "ERROR",
      "Device check failed",
      deviceCheckResult
    );

    handleError("Device check failed", {
      name: "DeviceCheckError",
      message: deviceCheckResult.errors.join(", ")
    });

    joinRoomToggle = false;
    connectionInProgress = false;
    return;
  }

  sendWidgetEvent(
    "DEVICE_CHECK_PASSED",
    "INFO",
    "Device check passed",
    deviceCheckResult
  );

  log("Joining room '" + roomName + "'...");
  log(
    "Creating local tracks. Camera: " +
    videoEnabled +
    ", Microphone: " +
    audioEnabled +
    ", Width: " +
    videoWidth +
    ", Height: " +
    videoHeight
  );

  var localTracksPromise;

  if (!audioEnabled && !videoEnabled) {
    log("Joining without local audio/video tracks");
    localTracksPromise = Promise.resolve([]);
  } else {
    localTracksPromise = hasActiveLocalTracks()
      ? Promise.resolve(localTracks)
      : Video.createLocalTracks({
          audio: audioEnabled,
          video: videoEnabled
            ? {
                width: videoWidth,
                height: videoHeight
              }
            : false
        });
  }

  localTracksPromise.then(
    function(tracks) {
      localTracks = tracks && tracks.length > 0 ? tracks : null;
      connectOptions.tracks = tracks || [];

      Video.connect(token, connectOptions).then(
        function(room) {
          roomJoined(room, identity);
        },
        function(error) {
          joinRoomToggle = false;
          connectionInProgress = false;
          handleError("Could not connect to Twilio", error);
        }
      );
    },
    function(error) {
      joinRoomToggle = false;
      connectionInProgress = false;
      handleError("Unable to access Camera and Microphone", error);
    }
  );
}

function clearPreviewContainer() {
  var previewContainer = getPreviewContainer();

  if (previewContainer) {
    while (previewContainer.firstChild) {
      previewContainer.removeChild(previewContainer.firstChild);
    }
  }
}

function stopLocalTracks() {
  if (localTracks) {
    localTracks.forEach(function(track) {
      try {
        detachTrack(track);

        if (track.mediaStreamTrack && typeof track.mediaStreamTrack.stop === "function") {
          track.mediaStreamTrack.stop();
        }

        if (typeof track.stop === "function") {
          track.stop();
        }
      } catch (e) {
        console.error("Error stopping local track", e);
      }
    });

    localTracks = null;
  }

  clearPreviewContainer();
}

// Leave Room.
function leaveRoom() {
  var hadActiveSession = activeRoom || localTracks || joinRoomToggle || previewToggle;

  if (hadActiveSession) {
    sendWidgetEvent(
      "SESSION_END_REQUESTED",
      "INFO",
      "User requested session termination"
    );
  }

  joinRoomToggle = false;
  previewToggle = false;
  connectionInProgress = false;

  if (activeRoom) {
    try {
      activeRoom.disconnect();
    } catch (e) {
      console.error("Error disconnecting room", e);
    }
  }

  stopLocalTracks();
  clearPreviewContainer();
  activeRoom = null;
}

function getPreviewContainer() {
  var selector = chat.props.previewSelector || 'div.twilio-video div.local-media';
  return document.querySelector(selector);
}

function showPreview() {
  if (isAgentParticipant()) {
    log("Camera preview skipped - agent participant does not use local media");
    previewToggle = false;
    return;
  }

  var defaultMediaEnabled = getDefaultMediaEnabled();
  var videoEnabled = getBooleanProp("cameraEnabledExpr", defaultMediaEnabled);

  if (!videoEnabled) {
    log("Camera preview skipped - camera disabled");
    previewToggle = false;
    return;
  }

  previewToggle = true;

  var videoWidth = getIntegerProp("videoWidth", 640);
  var videoHeight = getIntegerProp("videoHeight", 480);

  log(
    "Creating local preview track. Camera: " +
    videoEnabled +
    ", Width: " +
    videoWidth +
    ", Height: " +
    videoHeight
  );

  var localTracksPromise = hasActiveLocalTracks()
    ? Promise.resolve(localTracks)
    : Video.createLocalTracks({
        audio: false,
        video: {
          width: videoWidth,
          height: videoHeight
        }
      });

  localTracksPromise.then(
    function(tracks) {
      localTracks = tracks;
      var previewContainer = getPreviewContainer();
      if (previewContainer && !previewContainer.querySelector('video')) {
        attachTracks(tracks, previewContainer);
      }
    },
    function(error) {
      previewToggle = false;
      handleError("Unable to access Camera", error);
    }
  );
}

function executeAction(actionName) {
  var action = chat && chat.props ? chat.props[actionName] : null;

  if (action && action.canExecute && !action.isExecuting) {
    action.execute();
  }
}

function sendWidgetEvent(eventType, eventLevel, message, details = {}) {

  if (!chat || !chat.props) {
    return;
  }

  const payload = buildWidgetEvent({
    eventType,
    eventLevel,
    sessionId: chat.props.roomNameExpr?.value || "",
    participantIdentity: chat.props.nickNameExpr?.value || "",
    participantSide: chat.props.participantSide || "",
    message,
    details
  });

  emitWidgetEvent({
    eventJsonAttribute: chat.props.eventJsonAttribute,
    onWidgetEvent: chat.props.onWidgetEvent,
    payload,
    logMessages: getBooleanProp("logActiveExpr", false)
  });
}

function handleError(message, error) {
  var fullMessage = error && error.message
    ? message + ": " + error.message
    : message;

  connectionInProgress = false;
  console.error(fullMessage, error || "");
  log(fullMessage);

  sendWidgetEvent(
    "FATAL_ERROR",
    "ERROR",
    fullMessage,
    {
      errorName: error && error.name ? error.name : "",
      errorCode: error && error.code ? error.code : "",
      errorMessage: error && error.message ? error.message : ""
    }
  );

}

function hidePreview() {
  previewToggle = false;

  if (!activeRoom) {
    stopLocalTracks();
  } else {
    clearPreviewContainer();
  }
}

// Attach the Track to the DOM.
function attachTrack(track, container) {
  if (!track || !container || typeof track.attach !== "function") {
    return;
  }
  container.appendChild(track.attach());
}

// Attach array of Tracks to the DOM.
function attachTracks(tracks, container) {
  tracks.forEach(function(track) {
    attachTrack(track, container);
  });
}

// Detach given track from the DOM.
function detachTrack(track) {
  if (!track || typeof track.detach !== "function") {
    return;
  }

  track.detach().forEach(function(element) {
    element.remove();
  });
}


// Removes remoteParticipant container from the DOM.
function removeParticipantContainer(participant) {
  if (participant) {
    const container = participantContainers[participant.identity];

    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }

    delete participantContainers[participant.identity];
  }
}

// A new RemoteTrack was published to the Room.
function trackPublished(publication, container) {
  if (publication.isSubscribed) {
    attachTrack(publication.track, container);
  }
  publication.on('subscribed', function(track) {
    //log('Subscribed to ' + publication.kind + ' track');
    attachTrack(track, container);
  });
  publication.on('unsubscribed', detachTrack);
}

// A RemoteTrack was unpublished from the Room.
function trackUnpublished(publication) {
  log(publication.kind + ' track was unpublished.');
}

// A new RemoteParticipant joined the Room
function participantConnected(participant, container) {
  let participantContainer = document.createElement('div');
  participantContainer.className = 'participant-container';
  container.appendChild(participantContainer);

  let tracksContainer = document.createElement('div');
  tracksContainer.className = 'participant-tracks';
  participantContainer.appendChild(tracksContainer);

  let nameContainer = document.createElement('div');
  nameContainer.className = 'participant-name';
  nameContainer.textContent = participant.identity;
  participantContainer.appendChild(nameContainer);

  participantContainers[participant.identity] = participantContainer;

  participant.tracks.forEach(function(publication) {
    trackPublished(publication, tracksContainer);
  });
  participant.on('trackPublished', function(publication) {
    trackPublished(publication, tracksContainer);
  });
  participant.on('trackUnpublished', trackUnpublished);
}

// Detach the Participant's Tracks from the DOM.
function detachParticipantTracks(participant) {
  var tracks = getTracks(participant);
  tracks.forEach(detachTrack);
}

// Get the Participant's Tracks.
function getTracks(participant) {
  return Array.from(participant.tracks.values()).filter(function(publication) {
      return publication.track;
    }).map(function(publication) {
      return publication.track;
    });
}

// Successfully connected!
function roomJoined(room, identity) {
  activeRoom = room;
  connectionInProgress = false;
  log("Joined as '" + identity + "'");

  sendWidgetEvent(
    "ROOM_CONNECTED",
    "INFO",
    "Connected to Twilio room",
    {
        roomName: room.name,
        identity: identity
    }
  );


  // Attach the Tracks of the Room's Participants.
  var remoteMediaContainer = document.querySelector('div.twilio-video div.remote-media');
  room.participants.forEach(function(participant) {
    log("Already in Room: '" + participant.identity + "'");
    participantConnected(participant, remoteMediaContainer);
  });

  // When a Participant joins the Room, log the event.
  room.on('participantConnected', function(participant) {
    log("Remote participant connected: '" + participant.identity + "'");
    
    sendWidgetEvent(
      "PARTICIPANT_CONNECTED",
      "INFO",
      "Remote participant connected",
      {
          participantIdentity: participant.identity
      }
    );

    participantConnected(participant, remoteMediaContainer);
  });

  // When a Participant leaves the Room, detach its Tracks.
  room.on('participantDisconnected', function(participant) {
    sendWidgetEvent(
      "PARTICIPANT_DISCONNECTED",
      "INFO",
      "Remote participant disconnected",
      {
          participantIdentity: participant.identity
      }
    );
    log("Remote participant disconnected: '" + participant.identity + "'");
    detachParticipantTracks(participant);
    removeParticipantContainer(participant);
  });

  // Once the LocalParticipant leaves the room, detach the Tracks
  // of all Participants, including that of the LocalParticipant.
  room.on('disconnected', function() {
    log('Left the room');

    sendWidgetEvent(
      "ROOM_DISCONNECTED",
      "INFO",
      "Disconnected from Twilio room"
    );


    detachParticipantTracks(room.localParticipant);
    room.participants.forEach(detachParticipantTracks);
    room.participants.forEach(removeParticipantContainer);
 
    stopLocalTracks();
    clearPreviewContainer();

    activeRoom = null;
    joinRoomToggle = false;
    previewToggle = false;
    connectionInProgress = false;
  });
}

// Activity log.
function log(message) {
  var logActive = chat.props.logActiveExpr.value;
  if (logActive) {
    var logSelector = chat.props.logSelector || 'div.twilio-video div.log';
    var logElmnt = document.querySelector(logSelector);
    if (logElmnt) {
      logElmnt.innerHTML += '<p>' + message + '</p>';
    }
  }
}

class TwilioVideoChat extends Component {

  componentWillMount() {
    chat = this;
  }

  componentWillUnmount() {
    leaveRoom();
  }

  componentDidUpdate() {
    if (this.props.joinRoomActiveExpr.value) {
      if (!joinRoomToggle) joinRoom();
    } else {
      if (joinRoomToggle) leaveRoom();
    }

    if (this.props.previewActiveExpr.value) {
      if (!previewToggle) showPreview();
    } else {
      if (previewToggle) hidePreview();
    }
  }

  render() {
    const showDiagnostics = this.props.showDiagnostics === true;
    const showFeatureList = this.props.showFeatureList === true;

    return (
      <div class="twilio-video">
        <div class="media remote-media"></div>
        <div class="media local-media"></div>
        <div class="log"></div>

        {showDiagnostics && (
          <div class="twilio-diagnostics">
            <div><strong>ISR Secure Video Widget</strong></div>
            <div>Version: {WIDGET_VERSION}</div>
            <div>Participant side: {this.props.participantSide}</div>
            <div>Connection state: {getConnectionState()}</div>
            <div>Twilio SDK: {TWILIO_SDK_VERSION}</div>
            <div>Browser: {getBrowserInfo()}</div>
          </div>
        )}

        {showFeatureList && (
          <div class="twilio-diagnostics">
            <div><strong>Supported Features</strong></div>
            <ul>
              {WIDGET_FEATURES.map(feature => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  }
}

export default hot(TwilioVideoChat);
